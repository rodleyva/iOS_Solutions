//
//  TicTacToeGame.swift
//  TTT_Solution
//
//  Created by Rodrigo Leyva on 11/30/21.
//

import Foundation

class Game{
    
    var currentTurnIdx: Int = 1
    var board: [[Int]] = [
        [0,0,0],
        [0,0,0],
        [0,0,0]
    ]
    
    
    func changeTurn(){
        if self.currentTurnIdx == 1{
            self.currentTurnIdx = 2
        }else{
            self.currentTurnIdx = 1
        }
    }
    
    func isTurnValid(x:Int, y:Int) -> Bool{
        if self.board[x][y] != 0 {
            return false
        }
        return true
    }
    
    func updateBoard(x: Int, y: Int){
        self.board[x][y] = currentTurnIdx
    }
    
    func resetGame(){
        for i in 0..<self.board.count{
            for j in 0..<self.board[i].count{
                self.board[i][j] = 0
            }
        }
        currentTurnIdx = 1
    }
    
    func isBoardFull()-> Bool{
        for i in 0..<self.board.count{
            for j in 0..<self.board[i].count{
                if self.board[i][j] == 0 {
                    return false
                }
            }
        }
        return true
    }
    
    func checkWinnerRow(row: Int)-> Int{
        if self.board[row][0] != 0{
            let currentPlayer = self.board[row][0]
            if self.board[row][1] == currentPlayer && self.board[row][2] == currentPlayer{
                return currentPlayer
            }
        }
        return 0
    }
    
    func checkWinnerColumn(col: Int) -> Int{
        if self.board[0][col] != 0 {
            let currentPlayer = self.board[0][col]
            if self.board[1][col] == currentPlayer && self.board[2][col] == currentPlayer{
                return currentPlayer
            }
        }
        return 0
    }
    
    func checkWinnerDiagnoal()-> Int{
        if self.board[0][0] != 0{
            let currentPlayer = self.board[0][0]
            if self.board[1][1] == currentPlayer && self.board[2][2] == currentPlayer{
                return currentPlayer
            }
        }
        
        if self.board[0][2] != 0{
            let currentPlayer = self.board[0][2]
            if self.board[1][1] == currentPlayer && self.board[2][0] == currentPlayer{
                return currentPlayer
            }
        }
        
        return 0
    }
    
    func playerWon() -> Int{
        var winner: Int = 0
        
        for index in 0..<self.board.count{
            winner = checkWinnerRow(row: index)
            if (winner != 0){
                break
            }
            
            winner = checkWinnerColumn(col: index)
            if (winner != 0){
                break
            }
            
        }
        if winner == 0{
            winner = checkWinnerDiagnoal()
        }
        if self.isBoardFull() {
            winner = 3
        }
        
        
        return winner
    }
    
    
}

