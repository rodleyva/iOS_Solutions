//
//  ViewController.swift
//  TTT_Solution
//
//  Created by Rodrigo Leyva on 11/30/21.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var button00: UIButton!
    @IBOutlet weak var button01: UIButton!
    @IBOutlet weak var button02: UIButton!
    @IBOutlet weak var button10: UIButton!
    @IBOutlet weak var button11: UIButton!
    @IBOutlet weak var button12: UIButton!
    @IBOutlet weak var button20: UIButton!
    @IBOutlet weak var button21: UIButton!
    @IBOutlet weak var button22: UIButton!
    
    
    let gameObject = Game()
    
    @IBOutlet weak var backgroundBlurView: UIView!
    
    @IBOutlet weak var effectsView: UIVisualEffectView!
    @IBOutlet weak var winnerLbl: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        effectsView.layer.cornerRadius = 30.0
        effectsView.clipsToBounds = true
        backgroundBlurView.layer.cornerRadius = 30.0
        backgroundBlurView.clipsToBounds = true
        winnerLbl.text = ""
        setButtonColors()

        // Do any additional setup after loading the view.
    }
    
    func setButtonColors(){
        button00.backgroundColor = UIColor(named: "SquareColor")
        button01.backgroundColor = UIColor(named: "SquareColor")
        button02.backgroundColor = UIColor(named: "SquareColor")
        
        button10.backgroundColor = UIColor(named: "SquareColor")
        button11.backgroundColor = UIColor(named: "SquareColor")
        button12.backgroundColor = UIColor(named: "SquareColor")
        
        button20.backgroundColor = UIColor(named: "SquareColor")
        button21.backgroundColor = UIColor(named: "SquareColor")
        button22.backgroundColor = UIColor(named: "SquareColor")
    }
    
    @IBAction func resetButtonPressed(_ sender: Any) {
        gameObject.resetGame()
        setButtonColors()
        winnerLbl.text = ""
        
    }
    
    func updateButton(sender: UIButton, x: Int, y: Int){
        if gameObject.currentTurnIdx == 1 && gameObject.isTurnValid(x: x, y: y){
            
            self.winnerLbl.text = ""
            sender.backgroundColor = .red
            gameObject.updateBoard(x: x, y: y)
            
            
            let playerWon = gameObject.playerWon()
            if playerWon == 3{
                self.winnerLbl.text = "Tie no player Won"
            }else if playerWon != 0 {
                self.winnerLbl.text = "Player: \(playerWon == 1 ? "Red": "Blue" ) is the winner"
            }
            gameObject.changeTurn()
        }else if gameObject.currentTurnIdx == 2 && gameObject.isTurnValid(x: x, y: y){
            self.winnerLbl.text = ""
            sender.backgroundColor = .blue
            gameObject.updateBoard(x: x, y: y)
            
            let playerWon = gameObject.playerWon()

            if playerWon == 3{
                self.winnerLbl.text = "Tie no player Won"
            }else if playerWon != 0 {
                self.winnerLbl.text = "Player: \(playerWon == 1 ? "Red": "Blue" ) is the winner"
            }
            gameObject.changeTurn()


        }else{
            self.winnerLbl.text = "Not a valid move try again!"
        }
    }
    
//First row
    @IBAction func button00Pressed(_ sender: UIButton) {
        updateButton(sender: sender, x: 0, y: 0)
        
    }
    
    @IBAction func button01Pressed(_ sender: UIButton) {
        updateButton(sender: sender, x: 0, y: 1)
        
        
    }
    @IBAction func button02Pressed(_ sender: UIButton) {
        updateButton(sender: sender, x: 0, y: 2)
        
    }
    
//Second Row
    
    @IBAction func button10Pressed(_ sender: UIButton) {
        updateButton(sender: sender, x: 1, y: 0)
        
    }
    @IBAction func button11Pressed(_ sender: UIButton) {
        updateButton(sender: sender, x: 1, y: 1)
        
    }
    @IBAction func button12Pressed(_ sender: UIButton) {
        updateButton(sender: sender, x: 1, y: 2)
        
    }
    
//Third Row
    
    @IBAction func button20Pressed(_ sender: UIButton) {
        updateButton(sender: sender, x: 2, y: 0)
        
    }
    
    @IBAction func button21Pressed(_ sender: UIButton) {
        updateButton(sender: sender, x: 2, y: 1)
        
    }
    @IBAction func button22Pressed(_ sender: UIButton) {
        updateButton(sender: sender, x: 2, y: 2)
        
    }
}

