//
//  ViewController.swift
//  Tipster_Solution
//
//  Created by Rodrigo Leyva on 11/30/21.
//

import UIKit

class ViewController: UIViewController {

    var totalBill: Float = 0.0
    var totalBillString: String = ""
    var groupSize: Int = 1
    var senderValue: Float = 0.0

    @IBOutlet weak var totalLabel: UILabel!
    
    @IBOutlet weak var firstPercentage: UILabel!
    @IBOutlet weak var firstTip: UILabel!
    @IBOutlet weak var firstTotal: UILabel!
    
    
    @IBOutlet weak var secondPercentage: UILabel!
    @IBOutlet weak var secondTip: UILabel!
    @IBOutlet weak var secondTotal: UILabel!

    
    @IBOutlet weak var thirdPercentage: UILabel!
    @IBOutlet weak var thirdTip: UILabel!
    @IBOutlet weak var thirdTotal: UILabel!
    
    
    @IBOutlet weak var tipSlider: UISlider!
    
    @IBOutlet weak var groupSlider: UISlider!
    @IBOutlet weak var groupSizeLabel: UILabel!
    
    
    @IBOutlet weak var numbersBlurView: UIVisualEffectView!
    @IBOutlet weak var numbersView: UIView!
    @IBOutlet weak var percentBlurView: UIVisualEffectView!
    @IBOutlet weak var percentView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        totalLabel.text = "0.00"
        
        numbersView.layer.cornerRadius = 12.0
        numbersView.clipsToBounds = true
        numbersBlurView.layer.cornerRadius = 12.0
        numbersBlurView.clipsToBounds = true
        
        percentView.layer.cornerRadius = 12.0
        percentView.clipsToBounds = true
        percentBlurView.layer.cornerRadius = 12.0
        percentBlurView.clipsToBounds = true
        
        
        
        // Do any additional setup after loading the view.
    }
    
    func calculateTotal(total: Float){
        if let billFloat = Float(totalBillString){
            totalBill = billFloat
            
            let first = (totalBill * (total + 0.05)) / Float(groupSize)
            firstTip.text = String(format: "%.2f", first)
            firstTotal.text = String(format: "%.2f", (totalBill + first))
            
            let second = (totalBill * (total + 0.15)) / Float(groupSize)
            secondTip.text = String(format: "%.2f", second)
            secondTotal.text = String(format: "%.2f", (totalBill + second))
            
            let third = (totalBill * (total + 0.2)) / Float(groupSize)
            thirdTip.text = String(format: "%.2f", third)
            thirdTotal.text = String(format: "%.2f", (totalBill + third))
            
        }
    }
    
    
    @IBAction func tipValueChanged(_ sender: UISlider) {
        
        print(sender.value)
        
        firstPercentage.text = String(format: "%.2f", ((sender.value + 0.05) * 100)) + "%"
        secondPercentage.text = String(format: "%.2f", ((sender.value + 0.15) * 100)) + "%"
        thirdPercentage.text = String(format: "%.2f", ((sender.value + 0.2) * 100)) + "%"
        
        senderValue = sender.value
        calculateTotal(total: sender.value)
        
        
        
    }
    @IBAction func groupSizeChaged(_ sender: UISlider) {
        groupSizeLabel.text = "Group Size: \(Int(sender.value.rounded()))"
        groupSize = Int(sender.value.rounded())
        calculateTotal(total: senderValue)
    }
    
    @IBAction func point(_ sender: UIButton) {
        totalBillString += "."
        totalLabel.text = totalBillString
    }
    @IBAction func clear(_ sender: UIButton) {
        totalLabel.text = "0.00"
        totalBillString = ""
        totalBill = 0.0
        totalBillString = ""
        groupSize = 1
        senderValue = 0.0
        firstTip.text = "0"
        firstTotal.text = "0"
        secondTip.text = "0"
        secondTotal.text = "0"
        thirdTip.text = "0"
        thirdTotal.text = "0"
    }
    
    @IBAction func zero(_ sender: UIButton) {
        totalBillString += "0"
        totalLabel.text = totalBillString
    }
    @IBAction func one(_ sender: UIButton) {
        totalBillString += "1"
        totalLabel.text = totalBillString
    }
    @IBAction func two(_ sender: UIButton) {
        totalBillString += "2"
        totalLabel.text = totalBillString
    }
    
    @IBAction func three(_ sender: UIButton) {
        totalBillString += "3"
        totalLabel.text = totalBillString
    }
    @IBAction func four(_ sender: UIButton) {
        totalBillString += "4"
        totalLabel.text = totalBillString
    }
    
    @IBAction func five(_ sender: UIButton) {
        totalBillString += "5"
        totalLabel.text = totalBillString
    }
    @IBAction func six(_ sender: UIButton) {
        totalBillString += "6"
        totalLabel.text = totalBillString
    }
    @IBAction func seven(_ sender: UIButton) {
        totalBillString += "7"
        totalLabel.text = totalBillString
    }
    
    @IBAction func eight(_ sender: UIButton) {
        totalBillString += "8"
        totalLabel.text = totalBillString
    }
    
    @IBAction func nine(_ sender: UIButton) {
        totalBillString += "9"
        totalLabel.text = totalBillString
    }
    

}


