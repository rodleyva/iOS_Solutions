//
//  APIManager.swift
//  MovieQuotes
//
//  Created by Rodrigo Leyva on 12/24/21.
//

import Foundation
import Alamofire

struct MovieResult: Codable{
    let page: Int
    let results: [Movie]
}

struct Movie: Codable{
    let id : Int
    let backdrop_path: String
    let title: String
    let poster_path: String
    let vote_average: Double
    let release_date: String
    let overview: String
}

class APIManager{
    
    
    static let shared = APIManager()
    let API_KEY = "07e191d7433965c0de71546cf94d10bf"
    
    
    func getTopMovies(completion: @escaping (Result<MovieResult,Error>)->Void){
        
        let baseURLString = "https://api.themoviedb.org/3/movie/top_rated?api_key=\(API_KEY)&language=en-US&page=1"
        let url = URL(string: baseURLString)!
        
        AF.request(url).responseDecodable(of: MovieResult.self){ response in
            
            switch response.result{
                
            case .success(let movieResult):
                completion(.success(movieResult))
                
            case .failure(let error):
                completion(.failure(error))
                
            }
            
        }
    }

    
    
    
}
