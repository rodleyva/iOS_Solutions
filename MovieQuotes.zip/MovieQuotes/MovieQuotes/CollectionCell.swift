//
//  CollectionCell.swift
//  MovieQuotes
//
//  Created by Rodrigo Leyva on 12/24/21.
//

import UIKit

class CollectionCell: UICollectionViewCell {
    @IBOutlet weak var movieTitleLabel: UILabel!
    
    @IBOutlet weak var movieImageView: UIImageView!
    
    override var isSelected: Bool {
        didSet {
            if self.isSelected {
                backgroundColor = UIColor.systemMint
            }
            else {
                backgroundColor = UIColor.clear
            }
        }
    }
}
