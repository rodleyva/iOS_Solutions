//
//  QuizViewController.swift
//  MovieQuotes
//
//  Created by Rodrigo Leyva on 12/24/21.
//

import UIKit
import AlamofireImage

protocol QuizDelegate: AnyObject{
    func clearSelectedMovies()
}

class QuizViewController: UIViewController {
    
    var selectedMovies: [Movie] = []
    @IBOutlet weak var textField: UITextField!
    
    weak var delegate: QuizDelegate?
    
    var suggestionsArray:[String] = []
    
    var currentQuestion = 0
    
    var currentScore = 0
    
    @IBOutlet weak var scoreLabel: UILabel!
    @IBOutlet weak var quoteLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        textField.delegate = self
        quoteLabel.text = selectedMovies[0].overview

        // Do any additional setup after loading the view.
    }
    
    @IBAction func questionMarkPressed(_ sender: UIButton) {
    }
    
    func nextQuestion(){
        textField.text = ""
        if currentQuestion >= selectedMovies.count - 1{
            let alertVC = UIAlertController(title: "Finished Quiz", message: "Select more movies to try again", preferredStyle: .alert)
            
            let alertAction = UIAlertAction(title: "OK", style: .destructive) { _ in
                self.delegate?.clearSelectedMovies()
                
                self.navigationController?.popViewController(animated: true)
            }
            alertVC.addAction(alertAction)
            
            present(alertVC, animated: true, completion: nil)
        }else{
            currentQuestion += 1
            updateQuote()
        }
        
    }
    
    func updateQuote() {
        quoteLabel.text = selectedMovies[currentQuestion].overview
    }
    func updateScore(){
        scoreLabel.text = "Score: \(currentScore)"
    }
    
    
    
    

}

extension QuizViewController: UITextFieldDelegate{
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
            return !autoCompleteText( in : textField, using: string, suggestionsArray: suggestionsArray)
    }
    
    func autoCompleteText( in textField: UITextField, using string: String, suggestionsArray: [String]) -> Bool {
            if !string.isEmpty,
                let selectedTextRange = textField.selectedTextRange,
                selectedTextRange.end == textField.endOfDocument,
                let prefixRange = textField.textRange(from: textField.beginningOfDocument, to: selectedTextRange.start),
                let text = textField.text( in : prefixRange) {
                let prefix = text + string
                let matches = suggestionsArray.filter {
                    $0.hasPrefix(prefix)
                }
                if (matches.count > 0) {
                    textField.text = matches[0]
                    if let start = textField.position(from: textField.beginningOfDocument, offset: prefix.count) {
                        textField.selectedTextRange = textField.textRange(from: start, to: textField.endOfDocument)
                        return true
                    }
                }
            }
            return false
        }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        //Sumbit quiz response
        
        
        if let text = textField.text{
            if text == selectedMovies[currentQuestion].title{
                currentScore += 1
                let alertVC = UIAlertController(title: "Correct!", message: nil, preferredStyle: .alert)
                
                var imageView = UIImageView(frame: CGRect(x: 10, y: 50, width: 250, height: 230))
                let height = NSLayoutConstraint(item: alertVC.view, attribute: .height, relatedBy: .equal, toItem: nil, attribute: .notAnAttribute, multiplier: 1, constant: 320)
                let width = NSLayoutConstraint(item: alertVC.view, attribute: .width, relatedBy: .equal, toItem: nil, attribute: .notAnAttribute, multiplier: 1, constant: 250)
                
                
                
                
                let alertAction = UIAlertAction(title: "OK", style: .destructive) { _ in
                    self.updateScore()
                    self.nextQuestion()
                }
                alertVC.addAction(alertAction)
                
                let posterPath = "https://image.tmdb.org/t/p/original\(selectedMovies[currentQuestion].poster_path)"
                imageView.af.setImage(withURL: URL(string: posterPath)!)
                imageView.contentMode = .scaleAspectFit

                alertVC.view.addSubview(imageView)
                alertVC.view.addConstraint(height)
                alertVC.view.addConstraint(width)
                
                present(alertVC, animated: true, completion: nil)
                
            }else{
                updateScore()
                nextQuestion()
            }
        }
        return true
    }
    
}
