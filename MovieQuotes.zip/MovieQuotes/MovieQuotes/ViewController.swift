//
//  ViewController.swift
//  MovieQuotes
//
//  Created by Rodrigo Leyva on 12/24/21.
//

import UIKit
import AlamofireImage

class ViewController: UIViewController {
    
    
    
    @IBOutlet weak var collectionView: UICollectionView!
    
    var movies = [Movie]()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.allowsMultipleSelection = true
        
        addSwipeGesture()
        
        
        getMovies()
        // Do any additional setup after loading the view.
    }
    
    func addSwipeGesture(){
        let gesture = UISwipeGestureRecognizer(target: self, action: #selector(startQuizVC))
        gesture.direction = .left
        view.addGestureRecognizer(gesture)
    }
    
    @objc func startQuizVC(){
        let vc = storyboard?.instantiateViewController(withIdentifier: "QuizViewController") as! QuizViewController
        
        var selectedMovies = [Movie]()
        var autoFillSuggestions = [String]()
        
        if let indexes = collectionView.indexPathsForSelectedItems{
            for index in indexes {
                selectedMovies.append(movies[index.row])
                autoFillSuggestions.append(movies[index.row].title)
            }
            vc.delegate = self
            vc.selectedMovies = selectedMovies
            vc.suggestionsArray = autoFillSuggestions
            self.navigationController?.pushViewController(vc, animated: true)
        }

        
        
        
        
    }
    
    func getMovies(){
        APIManager.shared.getTopMovies { result in
            switch result{
            case .success(let movieResults):
                self.movies = movieResults.results
                DispatchQueue.main.async {
                    self.collectionView.reloadData()
                }
            case .failure(let error):
                //diplay error
                print(error.localizedDescription)
            }
        }
    }
    
    
}
extension ViewController: QuizDelegate{
    func clearSelectedMovies() {
        guard let selectedItems = collectionView.indexPathsForSelectedItems else { return
            
        }
        for indexPath in selectedItems {
            collectionView.deselectItem(at: indexPath, animated: false)
            
        }
    }
    
    
}
extension ViewController: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout{
    
    
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return movies.count
    }
    
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! CollectionCell
        
        cell.movieTitleLabel.text = movies[indexPath.row].title
        
        let posterPath = "https://image.tmdb.org/t/p/w500\(movies[indexPath.row].poster_path)"
        
        cell.movieImageView.af.setImage(withURL: URL(string: posterPath)!)
        cell.movieImageView.layer.cornerRadius = 25
        cell.movieImageView.clipsToBounds = true
        
        
        return cell
    }
    
    
    
    
    
   
    
    
    
}

