//
//  ViewController.swift
//  TableViewsSections
//
//  Created by Rodrigo Leyva on 12/23/21.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

