//
//  APIManager.swift
//  WeatherApp
//
//  Created by Rodrigo Leyva on 12/26/21.
//

import Foundation
import CoreLocation
import Alamofire

struct WeatherModel: Codable{
    let weather: [Weather]
    let main: Temp
    let visibility: Int
    let name: String
    
}

struct Weather: Codable{
    let id: Int
    let main: String
    let description: String
    let icon: String
    
}

struct Temp: Codable{
    let temp: Double
    let temp_min: Double
    let temp_max: Double
    let humidity: Int
}

struct WeatherForecastModel: Codable{
    let list: [WeatherForecast]
}

struct WeatherForecast: Codable{
    let dt: Double
    let main: Temp
    let weather: [Weather]
    let dt_txt: String
    
}



class APIManager{
    static let shared = APIManager()
    
    let API_KEY = "038327cc60dcb8962c48bb08d3e340c9"
    
    func getForecastWeather(lat: CLLocationDegrees, long: CLLocationDegrees, completion: @escaping (Result<WeatherForecastModel,Error>)-> Void){
        
        let baseURL = "https://api.openweathermap.org/data/2.5/forecast?lat=\(lat)&lon=\(long)&appid=\(API_KEY)&units=imperial"
        
        AF.request(baseURL).responseDecodable(of: WeatherForecastModel.self){ result in
            
            switch result.result{
                
            case.success(let weatherModel):
                completion(.success(weatherModel))
                
            case .failure(let error):
                completion(.failure(error))
                
            }
        }
    }
    
    
    func getLocalWeather(lat: CLLocationDegrees, long: CLLocationDegrees, completion: @escaping (Result<WeatherModel,Error>)-> Void){
        
        
        let baseURL = "https://api.openweathermap.org/data/2.5/weather?lat=\(lat)&lon=\(long)&units=imperial&appid=\(API_KEY)"
        
        AF.request(baseURL).responseDecodable(of: WeatherModel.self){ result in
            
            switch result.result{
                
            case.success(let weatherModel):
                completion(.success(weatherModel))
                
            case .failure(let error):
                completion(.failure(error))
                
            }
        }
        
    }
    
    func getIconURL(icon: String)-> String{
        
        let base = "https://openweathermap.org/img/wn/\(icon)@2x.png"
        
        return base
        
    }
    
    
    
}
