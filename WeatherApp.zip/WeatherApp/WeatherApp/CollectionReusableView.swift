//
//  CollectionReusableView.swift
//  WeatherApp
//
//  Created by Rodrigo Leyva on 12/27/21.
//

import UIKit

class CollectionReusableView: UICollectionReusableView {
        
}
