//
//  DailyCell.swift
//  WeatherApp
//
//  Created by Rodrigo Leyva on 12/27/21.
//

import UIKit

class DailyCell: UICollectionViewCell {
    @IBOutlet weak var dayLabel: UILabel!
    
    @IBOutlet weak var humidityLabel: UILabel!
    @IBOutlet weak var timeLabel: UILabel!
    @IBOutlet weak var iconImageView: UIImageView!
    
    @IBOutlet weak var lowHighLabel: UILabel!
}
