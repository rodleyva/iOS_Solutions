//
//  HourlyCell.swift
//  WeatherApp
//
//  Created by Rodrigo Leyva on 12/27/21.
//

import UIKit

class HourlyCell: UICollectionViewCell {
    
    @IBOutlet weak var tempLabel: UILabel!
    @IBOutlet weak var hourLabel: UILabel!
}
