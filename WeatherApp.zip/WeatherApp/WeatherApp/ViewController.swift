//
//  ViewController.swift
//  WeatherApp
//
//  Created by Rodrigo Leyva on 12/26/21.
//

import UIKit
import CoreLocation
import MapKit
import AlamofireImage

class ViewController: UIViewController {
    
    let locationManager = CLLocationManager()
    
    var currentLocation: CLLocationCoordinate2D?
    
    var currentWeatherModel: WeatherModel?
    
    var forecastWeatherModel: WeatherForecastModel?

    @IBOutlet weak var dailyCollectionView: UICollectionView!
    @IBOutlet weak var iconImageView: UIImageView!
    @IBOutlet weak var tempLabel: UILabel!
    @IBOutlet weak var descriptionLabel: UILabel!
    @IBOutlet weak var cityNameLabel: UILabel!
    
    override func viewWillAppear(_ animated: Bool) {
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        getUserLocation()
        
        dailyCollectionView.delegate = self
        dailyCollectionView.dataSource = self
        
        
        
        // Do any additional setup after loading the view.
    }
    
    func getUserLocation(){
        
        // Ask for Authorisation from the User.
        locationManager.requestAlwaysAuthorization()

        // For use in foreground
        locationManager.requestWhenInUseAuthorization()

        if CLLocationManager.locationServicesEnabled() {
            locationManager.delegate = self
            locationManager.desiredAccuracy = kCLLocationAccuracyBest
            locationManager.startUpdatingLocation()
        }

    }
    
    func getCurrentWeather(locValue: CLLocationCoordinate2D){
        
        APIManager.shared.getLocalWeather(lat: locValue.latitude, long: locValue.longitude) { result in
            switch result{
            case .success(let weatherModel):
                self.currentWeatherModel = weatherModel
                //Update UI
                DispatchQueue.main.async {
                    self.descriptionLabel.text = weatherModel.weather[0].description
                    self.cityNameLabel.text = weatherModel.name
                    self.tempLabel.text = "\(weatherModel.main.temp)*F"
                    self.iconImageView.af.setImage(
                        withURL: URL(string: APIManager.shared.getIconURL(icon: weatherModel.weather[0].icon))!
                    )
                }
            case .failure(let error):
                print(error)
            }
        }
        
    }
    
    func getForecastWeatherModel(locValue: CLLocationCoordinate2D){
        APIManager.shared.getForecastWeather(lat: locValue.latitude, long: locValue.longitude) { result in
            switch result{
            case .success(let forecastWeatherModel):
                self.forecastWeatherModel = forecastWeatherModel
                //Update UI
                DispatchQueue.main.async {
                    self.dailyCollectionView.reloadData()
                }
            case .failure(let error):
                print(error)
            }
        }
    }


}
extension ViewController: CLLocationManagerDelegate{
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        guard let locValue: CLLocationCoordinate2D = manager.location?.coordinate else{ return
            print("no location")
        }
        
        self.currentLocation = locValue
        
        print("locations = \(locValue.latitude) \(locValue.longitude)")
        
        getCurrentWeather(locValue: locValue)
        getForecastWeatherModel(locValue: locValue)
    }
}

extension ViewController: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return forecastWeatherModel?.list.count ?? 0
        
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = dailyCollectionView.dequeueReusableCell(withReuseIdentifier: "dailyCell", for: indexPath) as! DailyCell
        
        if let forecastModel = self.forecastWeatherModel{
            let date = Date(timeIntervalSince1970: forecastModel.list[indexPath.row].dt)
            let dateFormatter = DateFormatter()
            dateFormatter.timeStyle = DateFormatter.Style.long //Set time style
            dateFormatter.dateStyle = DateFormatter.Style.medium //Set date style
            dateFormatter.timeZone = .current
            dateFormatter.dateFormat = "HH:mm"
            let localTime = dateFormatter.string(from: date)
            
            cell.dayLabel.text = "\(date.dayOfWeek()!)"
            cell.timeLabel.text = localTime
            cell.humidityLabel.text = "Humidity: \(forecastModel.list[indexPath.row].main.humidity)"
            cell.lowHighLabel.text = "\(forecastModel.list[indexPath.row].main.temp_max)*F ⬆️\n\(forecastModel.list[indexPath.row].main.temp_min)*F ⬇️ "
            
            cell.iconImageView.af.setImage(withURL: URL(string: APIManager.shared.getIconURL(icon: forecastModel.list[indexPath.row].weather[0].icon))!)
            
        }
        
        cell.backgroundColor = .blue.withAlphaComponent(CGFloat(Float.random(in: 0.0...0.7)))
        
        return cell
        
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        return CGSize(width: 160, height: 450)
        
    }
    
    
    
}

extension Date {
    func dayOfWeek() -> String? {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "EEEE"
        return dateFormatter.string(from: self).capitalized
        // or use capitalized(with: locale) if you want
    }
}

