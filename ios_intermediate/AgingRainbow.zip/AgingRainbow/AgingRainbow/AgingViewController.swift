//
//  ViewController.swift
//  AgingRainbow
//
//  Created by Rodrigo Leyva on 12/14/21.
//

import UIKit

class AgingViewController: UIViewController {

    let people:[String] = ["George", "Betty", "Fran", "Joe", "Helda", "Rodrigo","Kevin", "Danny", "Hussein", "Zed", "Sara", "Jeffy", "Anna"]
    
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
    }


}

extension AgingViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return people.count
    }
    
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ageCell", for: indexPath)
        
        cell.detailTextLabel?.text = "\(Int.random(in: 5...95)) years old"
        cell.detailTextLabel?.font = .preferredFont(forTextStyle: .title3)
        
        cell.textLabel?.text = people[indexPath.row]
        cell.textLabel?.font = .preferredFont(forTextStyle: .title3)
        
        return cell
    }
    
    
}

