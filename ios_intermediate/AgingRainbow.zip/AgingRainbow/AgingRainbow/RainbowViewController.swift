//
//  RainbowViewController.swift
//  AgingRainbow
//
//  Created by Rodrigo Leyva on 12/14/21.
//

import UIKit

class RainbowViewController: UIViewController {

    let colors:[UIColor] = [.red, .orange, .yellow, .green, .blue, .purple]
    
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self

        
    }


}
extension RainbowViewController: UITableViewDelegate, UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return colors.count
    }
        
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "rainbowCell", for: indexPath)
        
        cell.contentView.backgroundColor = colors[indexPath.row]
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120.0
    }
    
    
}
