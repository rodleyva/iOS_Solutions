//
//  CustomCell.swift
//  CustomDelegation
//
//  Created by Rodrigo Leyva on 12/8/21.
//

import UIKit

protocol CustomCellDelegate: AnyObject {
    func add(number: Int)
    func minus(number: Int)
}

class CustomCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    weak var delegate: CustomCellDelegate? //ViewController

    @IBOutlet weak var cellLabel: UILabel!
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    @IBAction func minusPressed(_ sender: Any) {
        print("minus pressed")
        
        ///Viewcontroller.minus(number(100))
        if let powerString = cellLabel.text{
            if let powerNumber = Int(powerString){
                delegate?.minus(number: powerNumber)
            }
        }
        
        
    }
    @IBAction func plusPressed(_ sender: Any) {
        print("plus pressed")
        
        if let powerString = cellLabel.text{
            if let powerNumber = Int(powerString){
                delegate?.add(number: powerNumber)
                //viewcontroller.add()
            }
        }

    }
}
