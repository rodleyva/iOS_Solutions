//
//  ViewController.swift
//  CustomDelegation
//
//  Created by Rodrigo Leyva on 12/8/21.
//

import UIKit



class ViewController: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    
    @IBOutlet weak var totalLabel: UILabel!
    
    var count = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
        // Do any additional setup after loading the view.
    }


}
extension ViewController: CustomCellDelegate{
    
    func add(number: Int) {
        count += number
        
        totalLabel.text = "\(count)"
    }
    
    func minus(number: Int) {
        count -= number
        
        totalLabel.text = "\(count)"
    }
    
    
}

extension ViewController: UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 16
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "customCell", for: indexPath) as! CustomCell
        
        //this part
        cell.delegate = self
        
        cell.cellLabel.text = "\(pow(10,indexPath.row))"
        //10^0
        //10^1
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    
    
    
    
}

