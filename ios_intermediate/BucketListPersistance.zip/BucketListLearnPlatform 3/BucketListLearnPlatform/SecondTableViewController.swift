//
//  SecondTableViewController.swift
//  BucketListLearnPlatform
//
//  Created by Rodrigo Leyva on 10/11/21.
//

import UIKit

protocol SecondVCDelegate: AnyObject{
    
    func itemAdd(with text: String)
    func itemEdit(with text: String, at indexPath: IndexPath?)
}



class SecondTableViewController: UITableViewController {
    
    weak var delegate: SecondVCDelegate?
    var edittedItem: String?
    var taskType: TaskType?
    var indexPath: IndexPath?
    
    
    @IBOutlet weak var textField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        textField.text = edittedItem
        
        // Uncomment the following line to preserve selection between presentations
        //
    }
    
    
    @IBAction func savePressed(_ sender: UIButton) {
        
        guard let text = textField.text else {
            return
        }
        
        switch taskType{
            
        case .add:
            delegate?.itemAdd(with: text)
            
        case .edit:
            delegate?.itemEdit(with: text, at: indexPath)
        case .none:
            print("no task type was ever set ")
        }
        
        self.navigationController?.popViewController(animated: true)
        
    }
    
}
