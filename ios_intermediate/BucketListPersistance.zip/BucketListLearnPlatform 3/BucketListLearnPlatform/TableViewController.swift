//
//  ViewController.swift
//  BucketListLearnPlatform
//
//  Created by Rodrigo Leyva on 10/11/21.
//

import UIKit
import CoreData

enum TaskType{
    case edit
    case add
}

class TableViewController: UITableViewController {
    
    var items:[Item] = []
    
    let managedObjectContext = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    

    override func viewDidLoad() {
        super.viewDidLoad()
        fetchAllItems()
        
        // Do any additional setup after loading the view.
    }
    
    func fetchAllItems(){
        let itemReqest = NSFetchRequest<NSFetchRequestResult>(entityName: "Item")
        
        do{
            let results = try managedObjectContext.fetch(itemReqest)
            items = results as! [Item]
        }catch{
            print(error.localizedDescription)
        }
    }
    
    func saveContext(){
        do{
            try managedObjectContext.save()
        }catch {
            print(error)
        }
    }
    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "bucketCell", for: indexPath)
        cell.textLabel?.text = items[indexPath.row].text
        return cell
    }
    
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return items.count
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let vc = storyboard?.instantiateViewController(withIdentifier: "SecondTableViewController") as! SecondTableViewController
        vc.indexPath = indexPath
        vc.taskType = .edit
        vc.delegate = self
        vc.edittedItem = items[indexPath.row].text
        
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        
        let item = items[indexPath.row]
        managedObjectContext.delete(item)
        saveContext()
        items.remove(at: indexPath.row)
        tableView.reloadData()
    }
    
    
    @IBAction func addButtonPressed(_ sender: UIBarButtonItem) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "SecondTableViewController") as! SecondTableViewController
        vc.taskType = .add
        vc.delegate = self
        
        self.navigationController?.pushViewController(vc, animated: true)

    }
    


}

extension TableViewController: SecondVCDelegate{
    func itemAdd(with text: String) {
        print("calling add")
        
        let newItemEntity = Item(context: managedObjectContext)
        newItemEntity.text = text
        saveContext()
        
        items.append(newItemEntity)
        tableView.reloadData()
        dismiss(animated: true, completion: nil)
    }
    
    func itemEdit(with text: String, at indexPath: IndexPath?) {
        guard let indexPath = indexPath else {
            return
        }
        print("calling edit")
        items[indexPath.row].text = text
        saveContext()
        tableView.reloadData()
        dismiss(animated: true, completion: nil)
    }
    
    
    
}

