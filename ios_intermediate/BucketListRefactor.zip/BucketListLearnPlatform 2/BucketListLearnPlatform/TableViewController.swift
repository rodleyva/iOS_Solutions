//
//  ViewController.swift
//  BucketListLearnPlatform
//
//  Created by Rodrigo Leyva on 10/11/21.
//

import UIKit

enum TaskType{
    case edit
    case add
}

class TableViewController: UITableViewController {
    
    var items:[String] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "bucketCell", for: indexPath)
        cell.textLabel?.text = items[indexPath.row]
        return cell
    }
    
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return items.count
    }
    
    //editting
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let vc = storyboard?.instantiateViewController(withIdentifier: "SecondTableViewController") as! SecondTableViewController
        vc.indexPath = indexPath
        vc.taskType = .edit
        vc.delegate = self
        vc.edittedItem = items[indexPath.row]
        
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    
    @IBAction func addButtonPressed(_ sender: UIBarButtonItem) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "SecondTableViewController") as! SecondTableViewController
        vc.taskType = .add
        vc.delegate = self
        
        self.navigationController?.pushViewController(vc, animated: true)

    }
    


}

//Delegate methods

extension TableViewController: SecondVCDelegate{
    func itemAdd(with text: String) {
        print("calling add")
        items.append(text)
        tableView.reloadData()
        //dismiss(animated: true, completion: nil)
    }
    
    func itemEdit(with text: String, at indexPath: IndexPath?) {
        guard let indexPath = indexPath else {
            return
        }
        print("calling edit")
        items[indexPath.row] = text
        tableView.reloadData()
        //dismiss(animated: true, completion: nil)
    }
    
    
    
}

