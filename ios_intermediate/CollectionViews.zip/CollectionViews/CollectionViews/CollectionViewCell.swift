//
//  CollectionViewCell.swift
//  CollectionViews
//
//  Created by Rodrigo Leyva on 12/16/21.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var label: UILabel!
}
