//
//  ViewController.swift
//  CollectionViews
//
//  Created by Rodrigo Leyva on 12/16/21.
//

import UIKit

class ViewController: UIViewController {

    let nums: [[Int]] = [[1,2,3,4,5,6,7,8,9,10],
    [11,12,13,14,15,16,17,18,19,20],
    [21,22,23,24,25,26,27,28,29,30],
    [31,32,33,34,35],
    [41,42,43,44,45]]
    
    
    var currentSegment = 1
    
    
    @IBOutlet weak var collectionView: UICollectionView!
    override func viewDidLoad() {
        super.viewDidLoad()
        collectionView.delegate = self
        collectionView.dataSource = self

        // Do any additional setup after loading the view.
    }
    
    
    
    @IBAction func segmentChanged(_ sender: UISegmentedControl) {
        
        //list.append(newItems)
        //tableview.reloaddata()
        switch sender.selectedSegmentIndex{
        case 0:
            currentSegment = 0
            collectionView.reloadData()
        case 1:
            currentSegment = 1
            collectionView.reloadData()
        case 2:
            currentSegment = 2
            collectionView.reloadData()
        case 3:
            currentSegment = 3
            collectionView.reloadData()
            
            
        default:
            print("error")
        }
    }
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }

}

extension ViewController: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout{
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return nums[currentSegment].count
    }
    
    
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! CollectionViewCell
        
        cell.label.text = "\(nums[currentSegment][indexPath.row])"
        
        return cell
        
        
    }
    
    
}
