//
//  SecondViewController.swift
//  Madlibs
//
//  Created by Rodrigo Leyva on 10/10/21.
//

import UIKit

protocol SecondDelegate: AnyObject{
    func sendSentenceBack(_ text: String)
}

class SecondViewController: UIViewController {
    @IBOutlet weak var adjectiveLabel: UITextField!
    
    @IBOutlet weak var nounLabel: UITextField!
    @IBOutlet weak var verbLabel2: UITextField!
    @IBOutlet weak var verbLabel1: UITextField!
        
    weak var delegate: SecondDelegate?
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func cancelPressed(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func submitPressed(_ sender: Any) {
        guard let noun = nounLabel.text else {return}
        guard let verb1 = verbLabel1.text else {return}
        guard let verb2 = verbLabel2.text else {return}
        guard let adjective = adjectiveLabel.text else {return}
        let sentence = "We are having a perfectly \(adjective) right now. Later we will \(verb1) and \(verb2) in the \(noun)"
        
        delegate?.sendSentenceBack(sentence)
        
        self.dismiss(animated: true, completion: nil)
    }
    

}
