//
//  ViewController.swift
//  Madlibs
//
//  Created by Rodrigo Leyva on 10/10/21.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var sentenceLabel: UILabel!
    
    @IBOutlet weak var barButtonOutlet: UIBarButtonItem!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        sentenceLabel.text = "....."
        
    }
    
    @IBAction func pencilPressed(_ sender: Any) {
        
        let vc = storyboard?.instantiateViewController(withIdentifier: "SecondViewController") as! SecondViewController
        vc.delegate = self
        
        vc.modalPresentationStyle = .fullScreen
        
        present(vc, animated: true, completion: nil)
        
    }
    
    
    
}
extension ViewController: SecondDelegate{
    func sendSentenceBack(_ text: String) {
        sentenceLabel.text = text
    }
    
    
}

