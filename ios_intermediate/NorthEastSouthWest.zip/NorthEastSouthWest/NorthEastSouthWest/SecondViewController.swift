//
//  SecondViewController.swift
//  NorthEastSouthWest
//
//  Created by Rodrigo Leyva on 10/6/21.
//

import UIKit

class SecondViewController: UIViewController {

    var direction = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        directionLabel.text = direction

        // Do any additional setup after loading the view.
    }
    @IBOutlet weak var directionLabel: UILabel!
    

    @IBAction func dismissPressed(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    


}
